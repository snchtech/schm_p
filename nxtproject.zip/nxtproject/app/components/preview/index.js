import Symbol1Preview from './Symbol1Preview';

const PreviewLibrary = {
    symbol1Preview: Symbol1Preview,
};

export default PreviewLibrary;